<?php

if(file_exists("core/config.php"))
{
  include $_SERVER['DOCUMENT_ROOT']."/core/config.php";
}else{
  echo "Arquivo CONFIG.PHP inexistente! Confira os arquivos base do site, ou tente novamente mais tarde!";
  
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prototype - Church Web Service</title>
    <link rel="stylesheet" href="./css/hm-style.css" />
    <link rel="stylesheet" href="./css/global.css" />
    <link rel="icon" type="image/x-icon" href="<?php echo $domain; ?>/img/logo.png">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@7.4.47/css/materialdesignicons.min.css">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <script src="https://kit.fontawesome.com/2546cc9843.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
</head>
<body>
      <?php
      if(file_exists("./pages/navbar.php")){
         include $_SERVER['DOCUMENT_ROOT']."/pages/navbar.php";
      }else{
        echo "<div class='alert primary'>NAVBAR MISSING!!</div>";
      }
      ?>


      <div id="carouselExample" class="carousel slide crr-cus">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="https://wallpapers.com/images/featured/synthwave-background-3duulo8zigxt1b1f.jpg" class="d-block w-100" alt="...">
          </div>
          <div class="carousel-item">
            <img src="https://wallpapers.com/images/featured/synthwave-8g1vveyci7ahqyp5.jpg" class="d-block w-100" alt="...">
          </div>
          <div class="carousel-item">
            <img src="https://livewallp.com/wp-content/uploads/2021/08/classic-Synthwave.jpg" class="d-block w-100" alt="...">
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
       
    <main class="container main-slides">
      <div class="row mt-4 content-mainner">
       <div class="col-lg-5"> 
         <span class="display-6">Quem somos?</span>  
         <hr>
         <p class="lead">
          Ao contrário do que se acredita, Lorem Ipsum não é simplesmente um texto randômico. Com mais de 2000 anos, suas raízes podem ser encontradas em uma obra de literatura latina clássica datada de 45 AC. 
         </p>   
       </div>
       <div class="col-lg-5">
         <img class="images-content" src="https://3back.com/app/uploads/2017/07/Team-scaled.jpg">
       </div>
      </div>
      
    </main>
     
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
   
<footer>
   <span>&copy Presbytherin Church</span>
   
   <div class="footer-menu">    
      <ul class="footer-menu-ul">
        <a href="#">
          <li>Contato</li>
        </a>
        <a href="#">
          <li>Quem Somos</li>
        </a>
        <a href="#">
          <li>Doações</li>
        </a>
       
      </ul>
   </div>
</footer>
</body>
</html>