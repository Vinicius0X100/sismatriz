<nav class="navbar bg-dark fixed-top navbar-expand-lg">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">
            <img src="<?php echo $domain; ?>/img/logo.png" alt="Logo" width="56" height="56" class="d-inline-block align-text-top">
            <div class="left-head">
            <span class="text-white">Presbyterin Church</span>
            <span class="lead text-white">A Church for all nations</span>
            </div>
          </a>
          <div>
            <ul class="menu">
              <a href="<?php echo $domain; ?>"><li class="menu-items"><span class="mdi mdi-home-variant"></span> Home</li></a>
              <a href="<?php echo $domain; ?>/about-us"><li class="menu-items"><span class="mdi mdi-account-multiple"></span> Quem Somos</li></a>
              <a href="<?php echo $domain; ?>/donates"><li class="menu-items"><span class="mdi mdi-currency-usd"></span> Doações</li></a>
              <a href="<?php echo $domain; ?>/maps"><li class="menu-items"><span class="mdi mdi-google-maps"></span> Localização</li></a>
              <a href="<?php echo $domain; ?>/contact"><li class="menu-items"><span class="mdi mdi-cellphone-message"></span> Contato</li></a>
            </ul>
          </div>          
           <a href="<?php echo $domain; ?>/login" class="pers-btn">ENTRAR</a>
        </div>
      </nav>